pub mod strain;
